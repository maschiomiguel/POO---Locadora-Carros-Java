package viewer;

import model.AutomoveisDisponiveisArrayList;
import model.AutomoveisIndisponiveisArrayList;
import model.AutomoveisTotaisArrayList;
import model.Automovel;
import model.ClientesArrayList;
import model.ClientesPorCarroArrayList;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import excecoes.ExcecaoCarroJaExistente;
import excecoes.ExcecaoClienteJaCadastrado;
import excecoes.ExcecaoClienteNaoExistente;

public class InterfaceUsuario {

	private ClientesPorCarroArrayList clientecarro = new ClientesPorCarroArrayList();

	private AutomoveisDisponiveisArrayList autodisponiveis = new AutomoveisDisponiveisArrayList();

	private AutomoveisIndisponiveisArrayList autoindisponiveis = new AutomoveisIndisponiveisArrayList();

	private AutomoveisTotaisArrayList autototais = new AutomoveisTotaisArrayList();

	private ClientesArrayList clientes = new ClientesArrayList();

	private Scanner entrada = new Scanner(System.in);

	// vari�veis locais
	String cpfCliente;
	String placaCarro;
	Automovel aux = null;
	double vlrTaxa = 0;

	public void menu() throws ExcecaoClienteJaCadastrado, ExcecaoCarroJaExistente, ExcecaoClienteNaoExistente {
		int opcao;

		System.out.println("----------------------------------------");
		System.out.println("1-Cadastrar Cliente");
		System.out.println("2-Cadastrar Automovel");
		System.out.println("3-Apresentar clientes cadastrados");
		System.out.println("4-Apresentar autom�veis cadastrados");
		System.out.println("5-Alugar um autom�vel");
		System.out.println("6-Devolver um autom�vel");
		System.out.println("7-Consultar carros alugados e inquilinos");
		System.out.println("0-Sair");
		System.out.println("----------------------------------------");
		opcao = entrada.nextInt();

		while (opcao != 0) {
			vlrTaxa = 0;
			switch (opcao) {

			case 1:

				System.out.println("Nome do cliente: ");
				entrada.nextLine();
				String nomeCliente = entrada.nextLine();
				System.out.println("Cpf: ");
				String cpfCliente = entrada.nextLine();
				clientes.cadastrarCliente(nomeCliente, cpfCliente);
				break;

			case 2:

				System.out.println("Placa do carro: ");
				entrada.nextLine();
				String placaCarro = entrada.nextLine();
				System.out.println("Tipo (popular, medio ou grande): ");

				String tipoCarro = entrada.nextLine();
				System.out.println("Ano do carro: ");
				int anoCarro = entrada.nextInt();
				System.out.println("Valor base: ");
				double valorBase = entrada.nextDouble();
				autototais.cadastrarCarro(placaCarro, tipoCarro, anoCarro, valorBase);
				autodisponiveis.cadastrarCarro(placaCarro, tipoCarro, anoCarro, valorBase);
				break;

			case 3:

				clientes.getTodosClientes();

				break;

			case 4:

				autototais.getTodosAutomoveis();

				break;

			case 5:
				System.out.println("Carros Dispon�veis para loca��o: ");
				autodisponiveis.getDisponiveis();
				System.out.println("Digite a placa do carro que deseja alugar: ");
				entrada.nextLine();
				placaCarro = entrada.nextLine();
				System.out.println("Digite seu cpf: ");
				cpfCliente = entrada.nextLine();

				int i = clientes.verificarClientes(cpfCliente);

				if (i == 0) {
					System.out.println("Cliente n�o cadastrado.");
					break;
				}

				System.out.println("Data que deseja devolver o automovel (Obs: fomarto (DD/MM/YYYY): ");
				String dataDevolucao = entrada.nextLine();
				Calendar c = Calendar.getInstance();
				Date data = c.getTime();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String dataRecebida = sdf.format(data);

				aux = autodisponiveis.transferir(placaCarro);
				if (aux != null) {
					autoindisponiveis.inserirCarro(aux);
					autodisponiveis.removerCarro(placaCarro);
					clientecarro.adicionarAluguel(cpfCliente, placaCarro, dataRecebida, dataDevolucao);
				} else {
					System.out.println("Placa de carro n�o existe.");
				}

				break;

			case 6:
				System.out.println("Carros alugados: ");
				autoindisponiveis.getIndisponiveis();
				System.out.println("Digite a placa do carro que deseja devolver");
				entrada.nextLine();
				placaCarro = entrada.nextLine();
				System.out.println("Digite a data que est� devolvendo (Obs: fomarto (DD/MM/YYYY): ");
				dataDevolucao = entrada.nextLine();
				aux = autoindisponiveis.teste(placaCarro);
				if (aux != null) {
					autodisponiveis.inserirCarro(aux);
					vlrTaxa = autoindisponiveis.removerCarro(placaCarro);
					clientecarro.removerAluguel(placaCarro, vlrTaxa, dataDevolucao);
				} else {
					System.out.println("Placa de carro n�o existe.");
				}

				break;

			case 7:
				System.out.println("Carros alugados: ");
				clientecarro.getClientesPorCarro();

				break;

			}
			System.out.println("----------------------------------------");
			System.out.println("1-Cadastrar Cliente");
			System.out.println("2-Cadastrar Automovel");
			System.out.println("3-Apresentar clientes cadastrados");
			System.out.println("4-Apresentar autom�veis cadastrados");
			System.out.println("5-Alugar um autom�vel");
			System.out.println("6-Devolver um autom�vel");
			System.out.println("7-Consultar carros alugados e inquilinos");
			System.out.println("0-Sair");
			opcao = entrada.nextInt();
			System.out.println("----------------------------------------");
		}

	}

}
