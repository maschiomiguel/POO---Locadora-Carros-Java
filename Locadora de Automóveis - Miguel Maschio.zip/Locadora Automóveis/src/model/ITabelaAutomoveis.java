package model;

public interface ITabelaAutomoveis {
	
	private void valorAluguelFinal() {
	};

}
