package model;

/**
 * interface dos arraylists que envolvem o armazenamento dos autom�veis
 */

import excecoes.ExcecaoCarroJaExistente;

public interface IArraysAutomoveis {

	public void cadastrarCarro (String placa, String tipo, int anoDoCarro, double valorBase) throws ExcecaoCarroJaExistente;
	public double removerCarro (String placa);
	public void inserirCarro (Automovel automovel) throws ExcecaoCarroJaExistente;
	
}
	