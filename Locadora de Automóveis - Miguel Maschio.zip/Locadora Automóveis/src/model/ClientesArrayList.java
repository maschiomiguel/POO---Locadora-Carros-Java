package model;

import java.util.ArrayList;
import java.util.List;
import excecoes.ExcecaoClienteJaCadastrado;
import excecoes.ExcecaoClienteNaoExistente;

public class ClientesArrayList {
	
	private List<Cliente> todosClientes =  new ArrayList<Cliente>();
	
	/**
	 * m�todo para cadastro de um cliente
	 * @param nome - nome do cliente
	 * @param cpf - cpf do cliente
	 * @throws ExcecaoClienteJaCadastrado caso cliente j� esteja cadastrado
	 */
	
	public void cadastrarCliente (String nome, String cpf) throws ExcecaoClienteJaCadastrado
	{
		for (Cliente tcliente : todosClientes)
		{
			if (tcliente.getCpf() == cpf)
			{
				throw new ExcecaoClienteJaCadastrado();
			}
			
				
		}
		todosClientes.add(new Cliente(nome, cpf));
		
	}
	
	
	public void removerCliente (String cpf) throws ExcecaoClienteNaoExistente
	{
		
		int indice = -1;
		for (Cliente tcliente : todosClientes)
		{
			
			if (tcliente.getCpf() == cpf)
			{
				indice = todosClientes.indexOf(tcliente);
			}
			
		}
		if (indice >=0)
		{
			todosClientes.remove(indice);
		}
		else
			if(indice<=-1)
			{
				throw new ExcecaoClienteNaoExistente();
			}
		
	}
	
	public void getTodosClientes()
	{
		for (int i = 0; i<todosClientes.size(); i++)
		{
			System.out.println(i + 1 + " - " + todosClientes.get(i).getNome());
			System.out.println(i + 1 + " - " + todosClientes.get(i).getCpf());
		}
	}
	
	/**
	 * m�todo utilizado para verificar se o cpf do cliente est� cadastrado.
	 * confer�ncia para dar seguimento a loca��o do autom�vel
	 * @param cpfCliente utilizado para localizar o cpf cadastrado
	 */
	
	public int verificarClientes (String cpfCliente) throws ExcecaoClienteNaoExistente
	{
		int indice = -1;
		for (Cliente cliente : todosClientes)
		{
			if (cliente.getCpf().equals(cpfCliente))
			{
				indice = todosClientes.indexOf(cliente);
			}
		}
		if (indice<0)
		{
			return 0; 
		}
		return 1;
	}

}
