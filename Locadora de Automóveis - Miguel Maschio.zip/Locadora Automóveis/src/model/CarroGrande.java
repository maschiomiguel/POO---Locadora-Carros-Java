package model;

public class CarroGrande extends Automovel implements ITabelaAutomoveis {

	public CarroGrande(String placa, String tipo, int anoDoCarro, double valorBase) {
		super(placa, tipo, anoDoCarro, valorBase);
	}

	/**
	 * M�todo para calcular o valor final da di�ria do autom�vel com base no seu
	 * tipo
	 * 
	 * @return valor final da di�ria
	 */
	

	@Override
	public double valorAluguelFinal() {
		double valorFinal = 0;
		
			if (anoAtual - anoDoCarro <=0)
			{
				valorFinal = valorBase;
			}
		
			else if (anoAtual - anoDoCarro == 1) {

				valorFinal = (valorBase - (valorBase * 0.02));

			}

			else if (anoAtual - anoDoCarro == 2) 
			{
				valorFinal = (valorBase - (valorBase * 0.04));
			} 
			else if (anoAtual - anoDoCarro == 3) 
			{
				valorFinal = (valorBase - (valorBase * 0.06));
			} 
			else if (anoAtual - anoDoCarro > 3) 
			{
				valorFinal = (valorBase - (valorBase * 0.08));
			}
	
		return valorFinal;
	}

}
