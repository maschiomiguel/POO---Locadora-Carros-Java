package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import excecoes.ExcecaoClienteJaCadastrado;

public class ClientesPorCarroArrayList {

	private ArrayList<ClientePorCarro> carrosPorCliente = new ArrayList<ClientePorCarro>();

	/**
	 * m�todo para inserir os dados de um aluguel (cpf do cliente e placa do carro)
	 * 
	 * @param cpfCliente cpf do cliente que est� alugando um carro
	 * @param placaCarro carro que est� sendo alugado
	 * @throws ExcecaoClienteJaCadastrado cliente j� possui um carro alugado
	 */

	public void adicionarAluguel(String cpfCliente, String placaCarro, String dataLocacao, String dataDevolucao)throws ExcecaoClienteJaCadastrado

	{

		for (ClientePorCarro aux : carrosPorCliente) {
			if (aux.getCpfCliente().equals(cpfCliente)) {
				throw new ExcecaoClienteJaCadastrado();
			}
		}
		carrosPorCliente.add(new ClientePorCarro(cpfCliente, placaCarro, dataLocacao, dataDevolucao));

	}

	/**
	 * m�todo utilizado para remover um carro do arraylist dos alugados por clientes
	 * al�m de executar o c�lculo do valor final do aluguel
	 * @param placaCarro localiza o carro em quest�o
	 * @param vlrDiaria valor da di�ria calculada, utilizado para o valor final do aluguel
	 * @param dtDevol real data de devolu��o, a qual ser� comparada com a prevista para assim calcular o juros de 10% a di�ria
	 */
	public void removerAluguel(String placaCarro, double vlrDiaria, String dtDevol) {
		int indice = -1;
		double vlrTotal;
		SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
		for (ClientePorCarro aux : carrosPorCliente) {
			if (aux.getPlacaAlugada().equals(placaCarro)) {
				indice = carrosPorCliente.indexOf(aux);
			}
		}

		if (indice >= 0) {
			try {
				Date date1 = myFormat.parse(carrosPorCliente.get(indice).dataLocacao);
				Date date2 = myFormat.parse(carrosPorCliente.get(indice).dataDevolucao);
				long diff = date2.getTime() - date1.getTime();
				diff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

				vlrTotal = vlrDiaria * diff;

				date1 = myFormat.parse(carrosPorCliente.get(indice).dataDevolucao);
				date2 = myFormat.parse(dtDevol);
				diff = date2.getTime() - date1.getTime();
				diff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

				if (diff > 0) {
					date1 = myFormat.parse(carrosPorCliente.get(indice).dataDevolucao);
					date2 = myFormat.parse(dtDevol);
					diff = date2.getTime() - date1.getTime();
					diff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
					vlrTotal = vlrTotal + ((vlrDiaria * diff) + (((vlrDiaria * diff) * 10) / 100));
				}

				System.out.println("Valor total do aluguel: " + vlrTotal + " reais");

			} catch (ParseException e) 
			{
				e.printStackTrace();
			}
			carrosPorCliente.remove(indice);
		} 
		else 
		{
			
		}
	}

	/**
	 * m�todo para imprimir carro alugados e seus respectivos inquilinos
	 */

	public void getClientesPorCarro() {
		for (int i = 0; i < carrosPorCliente.size(); i++) {
			System.out.println(i + 1 + " - Cpf: " + carrosPorCliente.get(i).getCpfCliente());
			System.out.println(i + 1 + " - Placa: " + carrosPorCliente.get(i).getPlacaAlugada());
		}
	}

}
