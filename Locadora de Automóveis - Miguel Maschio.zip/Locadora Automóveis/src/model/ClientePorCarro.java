package model;

/**
 * Classe criada para vincular um cliente ao respectivo carro alugado pelo mesmo
 * @author Admin
 */

public class ClientePorCarro {

	String placaAlugada;
	String cpfCliente;
	String dataLocacao;
	String dataDevolucao;
	
	
	public ClientePorCarro (String cpfCliente, String PlacaAlugada, String dataLocacao, String dataDevolucao)
	{
		this.cpfCliente = cpfCliente;
		this.placaAlugada = PlacaAlugada;
		this.dataLocacao = dataLocacao;
		this.dataDevolucao = dataDevolucao;
	}


	public String getPlacaAlugada() {
		return placaAlugada;
	}


	public void setPlacaAlugada(String placaAlugada) {
		this.placaAlugada = placaAlugada;
	}


	public String getCpfCliente() {
		return cpfCliente;
	}


	public void setCpfCliente(String cpfCliente) {
		this.cpfCliente = cpfCliente;
	}
	
	

}
