package model;

import java.util.ArrayList;

import excecoes.ExcecaoCarroJaExistente;

public class AutomoveisTotaisArrayList implements IArraysAutomoveis {

	private ArrayList<Automovel> todosAutomoveis = new ArrayList<Automovel>();

	/**
	 * m�todo para cadastrar um carro novo a lista contendo todos autom�veis
	 */
	@Override
	public void cadastrarCarro(String placa, String tipo, int anoDoCarro, double valorBase)
			throws ExcecaoCarroJaExistente {
		for (Automovel auto : todosAutomoveis) {
			if (auto.getPlaca().equals(placa)) {
				throw new ExcecaoCarroJaExistente();
			}
		}

		if (tipo.equals("popular")) {
			todosAutomoveis.add(new CarroPopular(placa, tipo, anoDoCarro, valorBase));
		} else if (tipo.equals("medio")) {
			todosAutomoveis.add(new CarroMedio(placa, tipo, anoDoCarro, valorBase));
		} else if (tipo.equals("grande")) {
			todosAutomoveis.add(new CarroGrande(placa, tipo, anoDoCarro, valorBase));
		}
	}

	/**
	 * m�todo para remover um autom�vel
	 */
	@Override
	public double removerCarro(String placa) {
		int indice = -1;

		for (Automovel auto : todosAutomoveis) {
			if (placa == auto.getPlaca()) {
				indice = todosAutomoveis.indexOf(auto);
			}
		}
		if (indice >= 0) {
			todosAutomoveis.remove(indice);
		}
		return 0;
	}

	
	@Override
	public void inserirCarro(Automovel automovel) throws ExcecaoCarroJaExistente {

		for (Automovel auto : todosAutomoveis) {
			if (automovel.getPlaca() == auto.getPlaca()) {
				throw new ExcecaoCarroJaExistente();
			} else
				todosAutomoveis.add(automovel);
		}

	}

	/**
	 * m�todo que retorna todos autom�veis cadastrados
	 */
	public void getTodosAutomoveis() {
		for (int i = 0; i < todosAutomoveis.size(); i++) {
			System.out.println(i + 1 + " - Placa: " + todosAutomoveis.get(i).getPlaca());
			System.out.println(i + 1 + " - Tipo: " + todosAutomoveis.get(i).getTipo());
			System.out.println(i + 1 + " - Ano do carro: " + todosAutomoveis.get(i).getAnoDoCarro());
			System.out.println(i + 1 + " - Valor base: " + todosAutomoveis.get(i).getValorBase());
			System.out.println();
		}
	}

}
