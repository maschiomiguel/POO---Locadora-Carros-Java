package model;

import java.util.ArrayList;

import excecoes.ExcecaoCarroJaExistente;

/**
 * Lista de autom�veis indispon�veis
 * 
 * @author Miguel
 */

public class AutomoveisIndisponiveisArrayList implements IArraysAutomoveis {

	private ArrayList<Automovel> automoveisIndisponiveis = new ArrayList<Automovel>();

	@Override
	public void cadastrarCarro(String placa, String tipo, int anoDoCarro, double valorBase)
			throws ExcecaoCarroJaExistente {

		for (Automovel auto : automoveisIndisponiveis) {
			if (placa == auto.getPlaca()) {
				throw new ExcecaoCarroJaExistente();
			}
		}

		automoveisIndisponiveis.add(new Automovel(placa, tipo, anoDoCarro, valorBase));
	}

	/**
	 * m�todo para remover um carro dos indispon�veis
	 */
	@Override
	public double removerCarro(String placa) {

		int indice = -1;


		for (Automovel auto : automoveisIndisponiveis) {
			if (placa.equals(auto.getPlaca())) {
				indice = automoveisIndisponiveis.indexOf(auto);
			}
		}
		if (indice >= 0) {
			double vlrDiaria = automoveisIndisponiveis.get(indice).valorAluguelFinal();
			automoveisIndisponiveis.remove(indice);
			return vlrDiaria;
		}
		
		return 0;
	}

	/**
	 * m�todo para inserir um carro (usado para transferir de disponivel para
	 * indisponivel)
	 */
	
	public Automovel teste(String placa) {
		int flag = 0;
		
		for (int i = 0; i <automoveisIndisponiveis.size() && flag == 0; i++) {
			if (placa.equals(automoveisIndisponiveis.get(i).getPlaca())) {
				if (automoveisIndisponiveis.get(i).getTipo().equals("popular")) {
					CarroPopular aux =  new CarroPopular(automoveisIndisponiveis.get(i).getPlaca(), automoveisIndisponiveis.get(i).tipo , automoveisIndisponiveis.get(i).anoDoCarro, automoveisIndisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				} else if (automoveisIndisponiveis.get(i).getTipo().equals("medio")) {
					CarroMedio aux =  new CarroMedio(automoveisIndisponiveis.get(i).getPlaca(), automoveisIndisponiveis.get(i).tipo , automoveisIndisponiveis.get(i).anoDoCarro, automoveisIndisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				} else if (automoveisIndisponiveis.get(i).getTipo().equals("grande")) {
					CarroGrande aux =  new CarroGrande(automoveisIndisponiveis.get(i).getPlaca(), automoveisIndisponiveis.get(i).tipo , automoveisIndisponiveis.get(i).anoDoCarro, automoveisIndisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				}
			}
		}
		return null;
	}
	
	@Override
	public void inserirCarro(Automovel automovel) throws ExcecaoCarroJaExistente {

		for (Automovel auto : automoveisIndisponiveis) {
			if (automovel.getPlaca().equals(auto.getPlaca())) {
				throw new ExcecaoCarroJaExistente();
			} 
				
		}
		automoveisIndisponiveis.add(automovel);
	}
	
	/**
	 * m�todo que retorna carros j� alugados (indispon�veis)
	 */

	public void getIndisponiveis() {
		for (int i = 0; i < automoveisIndisponiveis.size(); i++) {
			System.out.println(i + 1 + " - Placa: " + automoveisIndisponiveis.get(i).getPlaca());
			System.out.println(i + 1 + " - Tipo: " + automoveisIndisponiveis.get(i).getTipo());
			System.out.println(i + 1 + " - Ano do carro: " + automoveisIndisponiveis.get(i).getAnoDoCarro());
			System.out.println(i + 1 + " - Valor base: " + automoveisIndisponiveis.get(i).getValorBase());
			System.out.println();
		}
	}
}
