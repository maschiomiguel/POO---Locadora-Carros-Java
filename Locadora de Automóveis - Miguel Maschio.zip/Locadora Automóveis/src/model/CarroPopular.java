package model;

public class CarroPopular extends Automovel implements ITabelaAutomoveis{
	
		
		
	public CarroPopular(String placa, String tipo, int anoDoCarro, double valorBase) {
		super(placa, tipo, anoDoCarro, valorBase);

	}

	/**
	 * M�todo para calcular o valor final da di�ria do autom�vel com base no seu tipo
	 * @return valor final da di�ria
	 */
	@Override
	public double valorAluguelFinal () 
		{
			double valorFinal = 0;
			if (anoAtual - anoDoCarro <=0)
			{
				valorFinal = valorBase;
			}
			else if (anoAtual-anoDoCarro == 1)
			{
				
				valorFinal = (this.valorBase - (this.valorBase * 0.07));
				
			}
			
			else 
				if (anoAtual-anoDoCarro == 2)
				{
					valorFinal = (this.valorBase - (this.valorBase * 0.14));
				}
				else 
					if (anoAtual-anoDoCarro >=3)
					{
						valorFinal = (this.valorBase - (this.valorBase * 0.21));
					}
			return valorFinal;
		}
		
	
	
}
