package model;

import java.util.ArrayList;

import excecoes.ExcecaoCarroJaExistente;

/**
 * Lista de autom�veis dispon�veis
 * 
 * @author Miguel
 */

public class AutomoveisDisponiveisArrayList implements IArraysAutomoveis {

	private ArrayList<Automovel> automoveisDisponiveis = new ArrayList<Automovel>();

	/**
	 * m�todo para cadastrar um carro novo aos dispon�veis (dando-o a hierarquia necess�ria)
	 */
	@Override
	public void cadastrarCarro(String placa, String tipo, int anoDoCarro, double valorBase)
			throws ExcecaoCarroJaExistente {
		for (Automovel auto : automoveisDisponiveis) {
			if (placa == auto.getPlaca()) {
				throw new ExcecaoCarroJaExistente();
			}

		}
		if (tipo.equals("popular")) {
			automoveisDisponiveis.add(new CarroPopular(placa, tipo, anoDoCarro, valorBase));
		} else if (tipo.equals("medio")) {
			automoveisDisponiveis.add(new CarroMedio(placa, tipo, anoDoCarro, valorBase));
		} else if (tipo.equals("grande")) {
			automoveisDisponiveis.add(new CarroGrande(placa, tipo, anoDoCarro, valorBase));
		}
	}

	/**
	 * m�todo que retorna um objeto "Automovel" completo para o m�todo de inser��o,
	 * para assim acontecer a movimenta��o para o arraylist de "Indispon�veis
	 * @return retorna um objeto "Automovel"
	 */

	public Automovel transferir(String placa) {
		int flag = 0;

		for (int i = 0; i < automoveisDisponiveis.size() && flag == 0; i++) {
			if (placa.equals(automoveisDisponiveis.get(i).getPlaca())) {
				if (automoveisDisponiveis.get(i).getTipo().equals("popular")) {
					CarroPopular aux =  new CarroPopular(automoveisDisponiveis.get(i).getPlaca(), automoveisDisponiveis.get(i).tipo , automoveisDisponiveis.get(i).anoDoCarro, automoveisDisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				} else if (automoveisDisponiveis.get(i).getTipo().equals("medio")) {
					CarroMedio aux =  new CarroMedio(automoveisDisponiveis.get(i).getPlaca(), automoveisDisponiveis.get(i).tipo , automoveisDisponiveis.get(i).anoDoCarro, automoveisDisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				} else if (automoveisDisponiveis.get(i).getTipo().equals("grande")) {
					CarroGrande aux =  new CarroGrande(automoveisDisponiveis.get(i).getPlaca(), automoveisDisponiveis.get(i).tipo , automoveisDisponiveis.get(i).anoDoCarro, automoveisDisponiveis.get(i).valorBase);
					flag = 1;
					return aux;
				}
			}
		}
		return null;
	}

	/**
	 * m�todo para inserir um carro (usado para transferir de indisponivel para
	 * disponivel)
	 */

	@Override
	public void inserirCarro(Automovel automovel) throws ExcecaoCarroJaExistente {
		for (Automovel auto : automoveisDisponiveis) {
			if (automovel.getPlaca().equals(auto.getPlaca())) {
				throw new ExcecaoCarroJaExistente();
			}
		}
		automoveisDisponiveis.add(automovel);
	}

	/**
	 * m�todo para remover um carro dos dispon�veis
	 */
	@Override
	public double removerCarro(String placa) {

		int indice = -1;

		for (Automovel auto : automoveisDisponiveis) {
			if (placa.equals(auto.getPlaca())) {
				indice = automoveisDisponiveis.indexOf(auto);
			}
		}
		if (indice >= 0) {
			automoveisDisponiveis.remove(indice);
		} else {
			System.out.println("placa n�o encontrada");
		}
		return 0;
	}

	/**
	 * M�todo para mostrar autom�veis dispon�veis para loca��o
	 * 
	 */

	public void getDisponiveis() {
		for (int i = 0; i < automoveisDisponiveis.size(); i++) {
			System.out.println(i + 1 + " - Placa: " + automoveisDisponiveis.get(i).getPlaca());
			System.out.println(i + 1 + " - Tipo: " + automoveisDisponiveis.get(i).getTipo());
			System.out.println(i + 1 + " - Ano do carro: " + automoveisDisponiveis.get(i).getAnoDoCarro());
			System.out.println(i + 1 + " - Valor base: " + automoveisDisponiveis.get(i).getValorBase());
			System.out.println();
		}
	}

}
