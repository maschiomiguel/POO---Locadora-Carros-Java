package model;

import java.util.Calendar;

/**
 * Classe pai dos autom�veis
 * 
 * @author Miguel
 */
public class Automovel {

	Calendar calendario = Calendar.getInstance();
	protected String placa;
	protected String tipo;
	protected int anoDoCarro;
	protected double valorBase;
	public int anoAtual = calendario.get(Calendar.YEAR);

	public Automovel(String placa, String tipo, int anoDoCarro, double valorBase) {
		this.placa = placa;
		this.tipo = tipo;
		this.anoDoCarro = anoDoCarro;
		this.valorBase = valorBase;
	}
	
	public double valorAluguelFinal() 
	{
		return 0;
	}
	
	public Calendar getCalendario() {
		return calendario;
	}

	public void setCalendario(Calendar calendario) {
		this.calendario = calendario;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getAnoDoCarro() {
		return anoDoCarro;
	}

	public void setAnoDoCarro(int anoDoCarro) {
		this.anoDoCarro = anoDoCarro;
	}

	public int getAnoAtual() {
		return anoAtual;
	}

	public void setAnoAtual(int anoAtual) {
		this.anoAtual = anoAtual;
	}

	public double getValorBase() {
		return valorBase;
	}

	public void setValorBase(double valorBase) {
		this.valorBase = valorBase;
	}

}
