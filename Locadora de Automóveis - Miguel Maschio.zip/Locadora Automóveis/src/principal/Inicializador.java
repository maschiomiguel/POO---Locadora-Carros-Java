package principal;

import excecoes.ExcecaoCarroJaExistente;
import excecoes.ExcecaoClienteJaCadastrado;
import excecoes.ExcecaoClienteNaoExistente;
import viewer.InterfaceUsuario;

public class Inicializador {
public static void main(String[] args) throws ExcecaoClienteJaCadastrado, ExcecaoCarroJaExistente, ExcecaoClienteNaoExistente {
		
		InterfaceUsuario interUsuario;
		interUsuario = new InterfaceUsuario();
		
		interUsuario.menu();

}
}
