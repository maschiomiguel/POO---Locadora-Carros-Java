package excecoes;

public class ExcecaoCarroJaExistente extends Exception{
	
	

}
