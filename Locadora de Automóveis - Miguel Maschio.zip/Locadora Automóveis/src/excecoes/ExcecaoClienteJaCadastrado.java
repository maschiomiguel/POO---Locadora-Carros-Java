package excecoes;

public class ExcecaoClienteJaCadastrado extends Exception{

}
