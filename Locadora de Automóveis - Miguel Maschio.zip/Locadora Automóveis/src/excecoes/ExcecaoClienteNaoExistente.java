package excecoes;

public class ExcecaoClienteNaoExistente extends Exception{

}
